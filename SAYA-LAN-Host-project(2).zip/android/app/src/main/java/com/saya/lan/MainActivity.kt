package com.saya.lan

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

private const val PORT = 47831
private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { SayaLanApp(applicationContext) }
 }
}

private object LanCrypto {
 private val salt = "SAYA-LAN-v1-pairing-salt".toByteArray(Charsets.UTF_8)
 fun derive(code: String): SecretKeySpec {
  require(code.length >= 12) { "کد اتصال باید حداقل ۱۲ نویسه باشد" }
  val spec = PBEKeySpec(code.toCharArray(), salt, 150_000, 256)
  val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
  spec.clearPassword()
  return SecretKeySpec(bytes, "AES")
 }
 fun encrypt(plain: ByteArray, key: SecretKeySpec): ByteArray {
  val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
  val cipher = Cipher.getInstance("AES/GCM/NoPadding")
  cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
  return iv + cipher.doFinal(plain)
 }
 fun decrypt(blob: ByteArray, key: SecretKeySpec): ByteArray {
  require(blob.size >= 28) { "بسته نامعتبر است" }
  val iv = blob.copyOfRange(0,12)
  val data = blob.copyOfRange(12,blob.size)
  val cipher = Cipher.getInstance("AES/GCM/NoPadding")
  cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128,iv))
  return cipher.doFinal(data)
 }
}

private data class ChatLine(val username:String, val text:String, val time:Long)

private class LocalStore(context: Context) {
 private val prefs = context.getSharedPreferences("saya_local_store", Context.MODE_PRIVATE)
 private val users = mutableMapOf<String, Pair<String,String>>() // username -> saltHex:hashHex, role
 private val messages = mutableListOf<ChatLine>()
 private val lock = Any()
 init {
  val raw = prefs.getString("users_json", null)
  if (raw == null) {
   createUser("admin", randomInitialPassword(), "admin")
  } else {
   val arr = JSONArray(raw)
   for (i in 0 until arr.length()) {
    val o=arr.getJSONObject(i); users[o.getString("u")] = o.getString("credential") to o.getString("role")
   }
  }
  loadMessages()
 }
 private fun randomInitialPassword(): String {
  val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#"
  return (1..20).map { chars[SecureRandom().nextInt(chars.length)] }.joinToString("")
 }
 fun initialPassword(): String = prefs.getString("initial_admin_password", "") ?: ""
 private fun persistUsers() {
  val arr=JSONArray()
  users.forEach { (u,v) -> arr.put(JSONObject().put("u",u).put("credential",v.first).put("role",v.second)) }
  prefs.edit().putString("users_json",arr.toString()).apply()
 }
 private fun hash(password:String, salt:ByteArray):ByteArray {
  val spec=PBEKeySpec(password.toCharArray(),salt,180_000,256)
  return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded.also { spec.clearPassword() }
 }
 private fun credential(password:String):String {
  val salt=ByteArray(16).also { SecureRandom().nextBytes(it) }
  return salt.joinToString("") { "%02x".format(it) } + ":" + hash(password,salt).joinToString("") { "%02x".format(it) }
 }
 private fun verify(password:String, stored:String):Boolean {
  return try {
   val p=stored.split(":"); val salt=hex(p[0]); val expected=hex(p[1])
   MessageDigest.isEqual(hash(password,salt),expected)
  } catch (_:Exception) { false }
 }
 private fun hex(s:String)=ByteArray(s.length/2) { i -> s.substring(i*2,i*2+2).toInt(16).toByte() }
 fun setupAdmin(password:String) {
  require(password.length>=14) { "رمز مدیر باید حداقل ۱۴ نویسه باشد" }
  synchronized(lock) {
   users["admin"] = credential(password) to "admin"; persistUsers()
   prefs.edit().putBoolean("admin_setup",true).remove("initial_admin_password").apply()
  }
 }
 fun adminConfigured()=prefs.getBoolean("admin_setup",false)
 fun authenticate(u:String,p:String):String? = synchronized(lock) {
  val v=users[u] ?: return null
  if (verify(p,v.first)) v.second else null
 }
 fun createUser(u:String,p:String,role:String="user") = synchronized(lock) {
  require(u.matches(Regex("[A-Za-z0-9_.-]{3,32}"))) { "نام کاربری ۳ تا ۳۲ نویسهٔ مجاز باشد" }
  require(p.length>=14) { "رمز عبور حداقل ۱۴ نویسه باشد" }
  require(!users.containsKey(u)) { "این نام کاربری وجود دارد" }
  users[u]=credential(p) to role; persistUsers()
 }
 fun userList():List<String> = synchronized(lock) { users.map { "${it.key} (${it.value.second})" }.sorted() }
 private fun persistMessages() {
  val arr=JSONArray()
  messages.forEach { arr.put(JSONObject().put("u",it.username).put("t",it.text).put("time",it.time)) }
  prefs.edit().putString("messages_json",arr.toString()).apply()
 }
 private fun loadMessages() {
  val raw=prefs.getString("messages_json","[]") ?: "[]"
  val arr=JSONArray(raw)
  for (i in 0 until arr.length()) {
   val o=arr.getJSONObject(i); val time=o.optLong("time")
   if (time + 3_600_000L > System.currentTimeMillis()) messages.add(ChatLine(o.optString("u"),o.optString("t"),time))
  }
  persistMessages()
 }
 fun send(u:String,t:String) = synchronized(lock) {
  purge(); messages.add(ChatLine(u,t,System.currentTimeMillis())); persistMessages()
 }
 fun allMessages():List<ChatLine> = synchronized(lock) { purge(); messages.toList() }
 private fun purge() { messages.removeAll { it.time + 3_600_000L <= System.currentTimeMillis() } }
}

private class LanHost(private val store:LocalStore, private val code:String) {
 @Volatile private var running=false
 private var server:ServerSocket?=null
 fun start() {
  if (running) return
  running=true
  scope.launch {
   try {
    server=ServerSocket(PORT)
    while (running) {
     val socket=server!!.accept()
     launch { handle(socket) }
    }
   } catch (_:Exception) { running=false }
  }
 }
 fun stop() { running=false; try { server?.close() } catch (_:Exception) {} }
 private fun handle(socket:Socket) {
  socket.use { s ->
   s.soTimeout=30_000
   val input=DataInputStream(BufferedInputStream(s.getInputStream()))
   val output=DataOutputStream(BufferedOutputStream(s.getOutputStream()))
   val key=LanCrypto.derive(code)
   while (running && !s.isClosed) {
    val size=try { input.readInt() } catch (_:Exception) { break }
    if (size !in 1..65536) break
    val packet=ByteArray(size); input.readFully(packet)
    val req=try { JSONObject(String(LanCrypto.decrypt(packet,key),Charsets.UTF_8)) } catch (_:Exception) { break }
    val res=try { process(req) } catch (e:Exception) { JSONObject().put("ok",false).put("error",e.message ?: "خطا") }
    val bytes=LanCrypto.encrypt(res.toString().toByteArray(Charsets.UTF_8),key)
    output.writeInt(bytes.size); output.write(bytes); output.flush()
   }
  }
 }
 private fun process(r:JSONObject):JSONObject {
  return when(r.optString("action")) {
   "login" -> {
    val u=r.optString("username"); val role=store.authenticate(u,r.optString("password"))
    if (role==null) JSONObject().put("ok",false).put("error","نام کاربری یا رمز نادرست است")
    else JSONObject().put("ok",true).put("username",u).put("role",role)
   }
   "send" -> {
    val u=r.optString("username"); val role=store.authenticate(u,r.optString("password"))
    if (role==null) JSONObject().put("ok",false).put("error","احراز هویت ناموفق")
    else {
     val t=r.optString("text")
     if (t.isBlank() || t.length>4000) JSONObject().put("ok",false).put("error","متن پیام نامعتبر است")
     else { store.send(u,t); JSONObject().put("ok",true) }
    }
   }
   "messages" -> {
    val u=r.optString("username"); val role=store.authenticate(u,r.optString("password"))
    if (role==null) JSONObject().put("ok",false).put("error","احراز هویت ناموفق")
    else {
     val arr=JSONArray()
     store.allMessages().forEach { arr.put(JSONObject().put("username",it.username).put("text",it.text).put("time",it.time)) }
     JSONObject().put("ok",true).put("messages",arr)
    }
   }
   "users" -> {
    val role=store.authenticate(r.optString("username"),r.optString("password"))
    if (role!="admin") JSONObject().put("ok",false).put("error","فقط مدیر")
    else JSONObject().put("ok",true).put("users",JSONArray(store.userList()))
   }
   "createUser" -> {
    val role=store.authenticate(r.optString("username"),r.optString("password"))
    if (role!="admin") JSONObject().put("ok",false).put("error","فقط مدیر")
    else { store.createUser(r.optString("newUsername"),r.optString("newPassword")); JSONObject().put("ok",true) }
   }
   else -> JSONObject().put("ok",false).put("error","درخواست ناشناخته")
  }
 }
}

private class LanClient(private val ip:String, private val code:String) {
 private val key=LanCrypto.derive(code)
 fun call(req:JSONObject):JSONObject {
  Socket().use { s ->
   s.connect(InetSocketAddress(ip,PORT),5000); s.soTimeout=10000
   val out=DataOutputStream(BufferedOutputStream(s.getOutputStream()))
   val input=DataInputStream(BufferedInputStream(s.getInputStream()))
   val packet=LanCrypto.encrypt(req.toString().toByteArray(Charsets.UTF_8),key)
   out.writeInt(packet.size); out.write(packet); out.flush()
   val n=input.readInt(); require(n in 1..65536) { "پاسخ میزبان نامعتبر است" }
   val response=ByteArray(n); input.readFully(response)
   return JSONObject(String(LanCrypto.decrypt(response,key),Charsets.UTF_8))
  }
 }
}

private fun localIps(context:Context):List<String> {
 val result=linkedSetOf<String>()
 try {
  val wm=context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
  @Suppress("DEPRECATION")
  val ip=wm.connectionInfo.ipAddress
  if (ip!=0) result.add("${ip and 255}.${ip shr 8 and 255}.${ip shr 16 and 255}.${ip shr 24 and 255}")
 } catch (_:Exception) {}
 try {
  val interfaces=java.net.NetworkInterface.getNetworkInterfaces()
  while (interfaces.hasMoreElements()) {
   val iface=interfaces.nextElement()
   val addresses=iface.inetAddresses
   while (addresses.hasMoreElements()) {
    val a=addresses.nextElement()
    if (!a.isLoopbackAddress && a is Inet4Address) result.add(a.hostAddress ?: "")
   }
  }
 } catch (_:Exception) {}
 return result.filter { it.isNotBlank() && it!="127.0.0.1" }.distinct()
}
private fun newPairingCode():String {
 val chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%"
 return (1..24).map { chars[SecureRandom().nextInt(chars.length)] }.joinToString("")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SayaLanApp(context:Context) {
 val store= remember { LocalStore(context) }
 var adminConfigured by remember { mutableStateOf(store.adminConfigured()) }
 var adminPassword by remember { mutableStateOf("") }
 var hostOn by remember { mutableStateOf(false) }
 var pairing by remember { mutableStateOf("") }
 var host by remember { mutableStateOf<LanHost?>(null) }
 var ips by remember { mutableStateOf(emptyList<String>()) }
 var ip by remember { mutableStateOf("") }
 var code by remember { mutableStateOf("") }
 var username by remember { mutableStateOf("") }
 var password by remember { mutableStateOf("") }
 var loggedIn by remember { mutableStateOf(false) }
 var role by remember { mutableStateOf("user") }
 var page by remember { mutableStateOf("home") }
 var message by remember { mutableStateOf("") }
 var messages by remember { mutableStateOf(listOf<String>()) }
 var users by remember { mutableStateOf(listOf<String>()) }
 var newUser by remember { mutableStateOf("") }
 var newPass by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("برای چت محلی، گوشی‌ها را به یک Wi-Fi متصل کنید.") }
 var busy by remember { mutableStateOf(false) }
 val uiScope= rememberCoroutineScope()

 MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF70E0BD))) {
  Scaffold(topBar={ TopAppBar(title={Text("SAYA • LAN Chat")}, actions={
   if (loggedIn) TextButton(onClick={ loggedIn=false; page="home"; username=""; password="" }) { Text("خروج") }
  }) }) { pad ->
   Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
    Text("بدون سرور اینترنتی • پیام‌ها پس از ۶۰ دقیقه منقضی می‌شوند", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
    Text("اطلاعیه حریم خصوصی: مدیر میزبان می‌تواند متن همه پیام‌ها را بخواند.", style=MaterialTheme.typography.bodySmall)
    if (status.isNotBlank()) Text(status, color=MaterialTheme.colorScheme.error)
    if (!adminConfigured) {
     Text("راه‌اندازی اولیه مدیر", style=MaterialTheme.typography.headlineSmall)
     Text("برای حساب admin یک رمز تازه و قوی تعیین کن.")
     OutlinedTextField(adminPassword,{adminPassword=it},label={Text("رمز مدیر (حداقل ۱۴ نویسه)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
     Button(onClick={
      try { store.setupAdmin(adminPassword); adminConfigured=true; status="مدیر ساخته شد. اکنون میزبان را روشن کن." }
      catch(e:Exception) { status=e.message ?: "خطا" }
     },modifier=Modifier.fillMaxWidth()) { Text("ساخت حساب مدیر") }
    } else if (page=="home") {
     Text("شبکه محلی", style=MaterialTheme.typography.headlineSmall)
     ElevatedCard(Modifier.fillMaxWidth()) {
      Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
       Text("۱) گوشی میزبان",style=MaterialTheme.typography.titleMedium)
       Text(if(hostOn) "میزبان فعال است • پورت $PORT" else "این گوشی می‌تواند میزبان گفتگوها باشد.")
       if (hostOn) {
        Text("آدرس‌های محلی: ${ips.joinToString()}")
        Text("کد اتصال: $pairing")
        Button(onClick={host?.stop();host=null;hostOn=false;pairing="";status="میزبان متوقف شد."},modifier=Modifier.fillMaxWidth()) { Text("توقف میزبان") }
       } else Button(onClick={
        try {
         pairing=newPairingCode(); ips=localIps(context)
         host=LanHost(store,pairing).also { it.start() }; hostOn=true
         status=if(ips.isEmpty()) "میزبان روشن شد؛ IP را از تنظیمات Wi-Fi گوشی پیدا کن." else "میزبان روشن شد. کد را فقط به کاربران مجاز بده."
        } catch(e:Exception) { status=e.message ?: "شروع میزبان ناموفق بود" }
       },modifier=Modifier.fillMaxWidth()) { Text("شروع میزبان") }
      }
     }
     ElevatedCard(Modifier.fillMaxWidth()) {
      Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
       Text("۲) اتصال به میزبان",style=MaterialTheme.typography.titleMedium)
       OutlinedTextField(ip,{ip=it},label={Text("IP گوشی میزبان")},modifier=Modifier.fillMaxWidth())
       OutlinedTextField(code,{code=it},label={Text("کد اتصال میزبان")},modifier=Modifier.fillMaxWidth())
       Text("هر دو گوشی باید روی یک شبکه Wi-Fi باشند.")
       Button(onClick={page="login"},modifier=Modifier.fillMaxWidth()) { Text("ادامه به ورود") }
      }
     }
    } else if (page=="login" && !loggedIn) {
     Text("ورود",style=MaterialTheme.typography.headlineSmall)
     OutlinedTextField(username,{username=it},label={Text("نام کاربری")},modifier=Modifier.fillMaxWidth())
     OutlinedTextField(password,{password=it},label={Text("رمز عبور")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
     Button(enabled=!busy,onClick={
      busy=true; status=""
      uiScope.launch {
       try {
        val result=withContext(Dispatchers.IO) { LanClient(ip,code).call(JSONObject().put("action","login").put("username",username).put("password",password)) }
        if(result.optBoolean("ok")) { loggedIn=true; role=result.optString("role"); page="chat"; status="ورود موفق" }
        else status=result.optString("error","ورود ناموفق")
       } catch(e:Exception) { status=e.message ?: "اتصال ناموفق" }
       busy=false
      }
     },modifier=Modifier.fillMaxWidth()) { Text(if(busy) "در حال اتصال…" else "ورود به چت") }
     TextButton(onClick={page="home"}) { Text("بازگشت") }
    } else if (loggedIn && page=="chat") {
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      Button(onClick={
       busy=true
       uiScope.launch {
        try {
         val r=withContext(Dispatchers.IO) { LanClient(ip,code).call(JSONObject().put("action","messages").put("username",username).put("password",password)) }
         if(r.optBoolean("ok")) {
          val a=r.getJSONArray("messages")
          messages=(0 until a.length()).map { i -> val m=a.getJSONObject(i); "${m.optString("username")}: ${m.optString("text")}" }
         } else status=r.optString("error")
        } catch(e:Exception) { status=e.message ?: "خطا" }
        busy=false
       }
      }) { Text("به‌روزرسانی پیام‌ها") }
      if(role=="admin") Button(onClick={page="admin"}) { Text("پنل مدیر") }
     }
     LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)) {
      items(messages) { line -> ElevatedCard(Modifier.fillMaxWidth()) { Text(line,Modifier.padding(12.dp)) } }
     }
     OutlinedTextField(message,{message=it},label={Text("پیام جدید")},modifier=Modifier.fillMaxWidth())
     Button(enabled=!busy,onClick={
      val text=message; busy=true
      uiScope.launch {
       try {
        val r=withContext(Dispatchers.IO) { LanClient(ip,code).call(JSONObject().put("action","send").put("username",username).put("password",password).put("text",text)) }
        if(r.optBoolean("ok")) { message=""; status="پیام ارسال شد." } else status=r.optString("error")
       } catch(e:Exception) { status=e.message ?: "ارسال ناموفق" }
       busy=false
      }
     },modifier=Modifier.fillMaxWidth()) { Text("ارسال") }
    } else if (loggedIn && page=="admin") {
     Text("پنل مدیریت محلی",style=MaterialTheme.typography.headlineSmall)
     Button(onClick={
      busy=true
      uiScope.launch {
       try {
        val r=withContext(Dispatchers.IO) { LanClient(ip,code).call(JSONObject().put("action","users").put("username",username).put("password",password)) }
        if(r.optBoolean("ok")) { val a=r.getJSONArray("users"); users=(0 until a.length()).map { a.getString(it) } }
        else status=r.optString("error")
       } catch(e:Exception) { status=e.message ?: "خطا" }
       busy=false
      }
     }) { Text("نمایش کاربران") }
     users.forEach { Text(it) }
     OutlinedTextField(newUser,{newUser=it},label={Text("نام کاربری جدید")},modifier=Modifier.fillMaxWidth())
     OutlinedTextField(newPass,{newPass=it},label={Text("رمز عبور جدید (۱۴ نویسه)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
     Button(onClick={
      busy=true
      uiScope.launch {
       try {
        val r=withContext(Dispatchers.IO) { LanClient(ip,code).call(JSONObject().put("action","createUser").put("username",username).put("password",password).put("newUsername",newUser).put("newPassword",newPass)) }
        status=if(r.optBoolean("ok")) "حساب ساخته شد." else r.optString("error")
       } catch(e:Exception) { status=e.message ?: "خطا" }
       busy=false
      }
     },modifier=Modifier.fillMaxWidth()) { Text("ساخت کاربر") }
     TextButton(onClick={page="chat"}) { Text("بازگشت به چت") }
    }
   }
  }
 }
}
