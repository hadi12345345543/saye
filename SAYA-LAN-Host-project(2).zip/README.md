# SAYA Secure Chat — LAN Host Edition (Android)

This edition removes the cloud server. One Android phone runs the local host, stores accounts/conversations/messages, and exposes a TCP endpoint to other phones on the same Wi-Fi/LAN. The host can read all messages, as requested; the app must clearly disclose this to users.

## Important security scope
- No internet server is used. The host phone is the server.
- Application payloads are encrypted with AES-256-GCM using a key derived from a shared pairing code (PBKDF2-HMAC-SHA256, 150,000 iterations). This is a starter transport protection, not a substitute for audited TLS. Anyone who learns the pairing code may be able to read traffic, so use a long, random pairing code and share it privately.
- Host can read messages by design. This is not end-to-end encryption.
- Message rows are removed after 60 minutes by the app's cleanup logic. Screenshots, copied text, notification previews, and external backups cannot be guaranteed erased.
- The host app must remain running for connections. Android may stop background work; keep it open during use. A production release should implement and test a foreground service with a persistent notification.
- The project is a starter and has not been independently security-audited or build-tested.

## Build
1. Install Android Studio stable and JDK 17.
2. Open `android/`.
3. Let Gradle sync.
4. Build > Build APK(s).
5. Install the same APK on all phones.

## Use
1. Connect all phones to the same trusted Wi-Fi router. Internet access is not required; a router can create a local network without WAN access. Avoid public Wi-Fi.
2. On the host phone, open SAYA and select **Start Host**. It displays the local IP addresses and a randomly generated pairing code.
3. On each client phone, choose **Connect to Host**, enter the host IP, port `47831`, and pairing code.
4. The host owner creates user accounts in the local admin panel. Initial admin account: `admin`; first-launch setup forces creation of a new password.
5. Share each user's credentials privately. Admin can read all chat content; users see this disclosure at login.
6. Keep the host phone awake and SAYA open while chatting.

## Limitations
- This starter uses a simple single-room chat for the prototype.
- Host phone is the only database holder. If it leaves Wi-Fi, clients cannot communicate.
- Some routers enable client isolation, which blocks phone-to-phone communication. Disable AP/client isolation or use another trusted router.
- For stronger production security, add TLS with certificate pinning, audited key exchange, rate limiting, foreground service, device pairing/revocation, database encryption at rest, automated tests, and an independent security review.
